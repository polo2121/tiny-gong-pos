// 1. The Standardized Error Class
export class ApiError extends Error {
  public statusCode: number;
  public context?: string;

  constructor(statusCode: number, message: string, context?: string) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.context = context;
  }
}

// 2. The Logger Utility
export const logger = {
  error: (context: string, error: unknown) => {
    // In the future, you can swap this console.error with Sentry or Datadog
    console.error(`[❌ ERROR] ${context}`, {
      message: error instanceof Error ? error.message : String(error),
      fullError: error,
      timestamp: new Date().toISOString()
    });
  },
  
  info: (context: string, data?: unknown) => {
    console.log(`[ℹ️ INFO] ${context}`, data ? data : '');
  },

  warn: (context: string, data?: unknown) => {
    console.warn(`[⚠️ WARN] ${context}`, data ? data : '');
  }
};