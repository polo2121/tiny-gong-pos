import { createClient } from "@/lib/supabase/server";
import {
  StoreMembership,
  storeMembershipSchema,
} from "@/lib/auth/types";

export async function getCurrentStoreMembership(): Promise<StoreMembership | null> {
  const supabase = await createClient();
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError) {
    throw new Error(authError.message);
  }

  if (!user) {
    return null;
  }

  const { data, error } = await supabase
    .from("store_members")
    .select(
      `
      role,
      store:stores (
        id,
        name
      )
      `,
    )
    .eq("user_id", user.id)
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }

  const storeRelation = data?.store;
  const store = Array.isArray(storeRelation) ? storeRelation[0] : storeRelation;

  if (!data || !store) {
    return null;
  }

  const membership = {
    storeId: store.id,
    storeName: store.name,
    role: data.role,
  };

  const validatedMembership = storeMembershipSchema.safeParse(membership);

  if (!validatedMembership.success) {
    throw new Error("Invalid store membership data.");
  }

  return validatedMembership.data;
}

export async function requireCurrentStoreMembership(): Promise<StoreMembership> {
  const membership = await getCurrentStoreMembership();

  if (!membership) {
    throw new Error("No store membership found for the current user.");
  }

  return membership;
}
