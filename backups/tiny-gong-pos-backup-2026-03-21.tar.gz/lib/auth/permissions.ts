import { StoreRole } from "./types";

const PRODUCT_EDITOR_ROLES: StoreRole[] = ["owner", "admin", "staff"];

export function canEditProducts(role: StoreRole): boolean {
  return PRODUCT_EDITOR_ROLES.includes(role);
}

export function canManageStore(role: StoreRole): boolean {
  return role === "owner" || role === "admin";
}
