import { z } from "zod";

const idSchema = z.string().uuid("Invalid ID format");

export const storeRoleSchema = z.enum(["owner", "admin", "staff", "viewer"]);

export const storeMembershipSchema = z.object({
  storeId: idSchema,
  role: storeRoleSchema,
  storeName: z.string(),
});

export type StoreRole = z.infer<typeof storeRoleSchema>;
export type StoreMembership = z.infer<typeof storeMembershipSchema>;
