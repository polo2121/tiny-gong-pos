import { ApiError, logger } from "./logger";
import type { PostgrestSingleResponse } from "@supabase/supabase-js";

function toStatusCode(rawCode?: string): number {
  const parsed = Number.parseInt(rawCode ?? "", 10);
  return Number.isNaN(parsed) ? 500 : parsed;
}

export const apiClient = {
  /**
   * Generic query wrapper:
   * - keeps error handling in one place
   * - keeps return type strongly typed with `T`
   */
  async query<T>(
    request: Promise<PostgrestSingleResponse<T>>,
    context: string = "Unnamed Database Query",
  ): Promise<T> {
    try {
      const { data, error } = await request;


      // Supabase returned an explicit error.
      if (error) {
        throw new ApiError(
          toStatusCode(error.code),
          error.message ?? "Database error",
          context,
        );
      }
      
      // No Supabase error, but data is still missing.
      if (data === null || data === undefined) {
        throw new ApiError(500, "No data returned from database", context);
      }

      // TypeScript now knows `data` is T (not null), so no cast needed.
      return data;
      
    } catch (err: unknown) {
      logger.error(`Query failed: ${context}`, err);

      // Keep known ApiError as-is.
      if (err instanceof ApiError) {
        throw err;
      }

      // Convert unknown runtime errors into a standard ApiError.
      throw new ApiError(500, "An unexpected client error occurred", context);
    }
  },
};
