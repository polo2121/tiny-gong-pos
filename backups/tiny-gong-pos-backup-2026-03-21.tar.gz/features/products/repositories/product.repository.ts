import { createClient } from "@/lib/supabase/server";
import {
  RemoveVariantPayload,
} from "@/features/products/schema/product.schema";
import {
  CategoryGroup,
  GetAllProductsPayload,
} from "@/features/products/types";

export async function getAllProductsByCategoryQuery(
  payload: GetAllProductsPayload,
): Promise<CategoryGroup[]> {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("get_catalog_grouped", {
    search_text: payload.searchText || null,
    search_by: payload.searchBy,
    page_number: payload.pageNumber,
    page_size: payload.pageSize,
  });

  if (error) {
    console.error(`[CatalogService] RPC Error: ${error.message}`, {
      code: error.code,
      details: error.details,
    });

    throw new Error(error.message);
  }

  return (data as CategoryGroup[]) ?? [];
}

type ProductDetailsRecord = {
  id: string;
  name: string;
  series_code: string;
  price: number;
  cost: number;
  categoryId: { id: string } | null;
  variants: {
    id: string;
    gender: string;
    color: string;
    size: string;
    stockQty: number;
  }[];
};

export async function getProductByIdQuery(
  productId: string,
): Promise<ProductDetailsRecord | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(
      `
      id,
      name,
      series_code,
      price,
      cost,
      categoryId:categories (
        id
      ),
      variants:product_variants (
        id,
        gender,
        color,
        size,
        stockQty:stock_qty
      )
      `,
    )
    .eq("id", productId)
    .is("variants.deleted_at", null)
    .maybeSingle();

  if (error) {
    console.error("❌ Supabase error:", {
      message: error.message,
      details: error.details,
      hint: error.hint,
      code: error.code,
    });

    throw new Error(`Database error: ${error.message}`);
  }

  return data as ProductDetailsRecord | null;
}

type VariantWithProductStoreRecord = {
  id: string;
  product:
    | {
        id: string;
        store_id: string;
      }
    | {
        id: string;
        store_id: string;
      }[]
    | null;
};

export async function getVariantWithProductStore(variantId: string) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("product_variants")
    .select(
      `
      id,
      product:products (
        id,
        store_id
      )
      `,
    )
    .eq("id", variantId)
    .is("deleted_at", null)
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }

  return data as VariantWithProductStoreRecord | null;
}

export async function removeVariantByIdQuery(payload: RemoveVariantPayload) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("product_variants")
    .update({
      deleted_at: new Date().toISOString(),
    })
    .eq("id", payload.id)
    .is("deleted_at", null)
    .select("id")
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}
