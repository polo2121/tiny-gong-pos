import React from "react";

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

import DualText from "@/components/DualText";

type HeaderSectionProps = {
  currentPath: string[];
  title: string;
  subtitle: string;
  sideContent?: React.ReactNode;
};

const HeaderSection = ({
  currentPath,
  title,
  subtitle,
  sideContent,
}: HeaderSectionProps) => {
  return (
    <section className="flex mt-10 border border-gray-300 rounded-lg p-6">
      {/* left */}
      <div className="flex flex-col gap-4">
        <Breadcrumb className="capitalize">
          <BreadcrumbList>
            {currentPath.map((path, index, pathArray) => (
              <React.Fragment key={path}>
                <BreadcrumbItem>
                  <BreadcrumbLink href={`/${path}`}>{path}</BreadcrumbLink>
                </BreadcrumbItem>

                {index < pathArray.length - 1 && <BreadcrumbSeparator />}
              </React.Fragment>
            ))}
          </BreadcrumbList>
        </Breadcrumb>

        <DualText primary={title} secondary={subtitle} size="lg" />
      </div>

      {/* Right */}
      <div>{sideContent ?? sideContent}</div>
    </section>
  );
};

export default HeaderSection;
