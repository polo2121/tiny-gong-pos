"use client";

import DualText from "@/components/DualText";

const ProductInventory = () => {
  return (
    <section className="flex flex-col gap-8 p-6">
      {/* Inventroy Header & View Toggle */}
      <div className="flex justify-between">
        <DualText
          primary="Product Inventory"
          secondary="ကုန်ပစ္စည်းအရေအတွက်"
          size="md"
        />
      </div>
    </section>
  );
};

export default ProductInventory;
