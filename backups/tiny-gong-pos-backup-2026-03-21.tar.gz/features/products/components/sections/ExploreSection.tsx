import React from "react";
import { NavCard } from "@/components/NavCard";

const ExploreSection = () => {
  return (
    <section className="p-6 grid grid-cols-1">
      <h2 className="text-2xl font-semibold mb-4">Explore</h2>
      <div className="w-full grid grid-cols-2 gap-4">
        <NavCard />
        <NavCard />
      </div>
    </section>
  );
};

export default ExploreSection;
