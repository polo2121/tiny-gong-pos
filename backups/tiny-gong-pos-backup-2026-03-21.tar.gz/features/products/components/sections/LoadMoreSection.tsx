import React from "react";

const LoadMoreSection = () => {
  return <div>LoadMoreSection</div>;
};

export default LoadMoreSection;
