import React from "react";
import MetricCard from "@/components/MetricCard";

const MetricSection = () => {
  const metricsData = [
    {
      title: "Total Products",
      subtitle: "စုစုပေါင်း ဝင်ငွေ",
      value: "10,000",
    },
    {
      title: "Total Costs",
      subtitle: "စုစုပေါင်း ကုန်ကျစရိတ်",
      value: "8,500",
    },
    {
      title: "Total in Stock",
      subtitle: "စုစုပေါင်း in Stock items",
      value: "1,500",
    },
    {
      title: "Total Out of Stock",
      subtitle: "စုစုပေါင်း ကုန်သွားပြီး items",
      value: "200",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
      {metricsData.map((metric) => (
        <MetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
};

export default MetricSection;
