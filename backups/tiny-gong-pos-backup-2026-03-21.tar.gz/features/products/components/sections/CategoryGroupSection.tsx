import React from "react";
import CategoryTag from "@/features/products/components/categories/CategoryTag";
import HeaderSection from "./HeaderSection";
import DualText from "@/components/DualText";

const CategoryGroupSection = () => {
  return (
    <section className=" bg-gray-400 flex flex-col gap-6 py-10">
      <DualText
        primary="Categories' Tag"
        secondary="ဒီနေ့ product အရရောင်းရဆုံးစာရင်း)"
        size="md"
        className="px-6"
      />
      <div className="grid grid-cols-5 gap-2 px-12">
        <CategoryTag name="Electronics" />
        <CategoryTag name="Clothing" />
        <CategoryTag name="Home & Kitchen" />
        <CategoryTag name="Home & Kitchen" />
        <CategoryTag name="Home & Kitchen" />

        <CategoryTag name="Electronics" />
        <CategoryTag name="Clothing" />
        <CategoryTag name="Home & Kitchen" />
        <CategoryTag name="Home & Kitchen" />
        <CategoryTag name="Home & Kitchen" />
      </div>
    </section>
  );
};

export default CategoryGroupSection;
