import React from "react";
import Image from "next/image";

const NoDataFound = () => {
  return (
    <div className="relative w-full flex flex-col justify-center items-center gap-2">
      <h1 className="text-base">
        Please check if the spelling is correct and try again.
      </h1>
      <p className="text-xs">
        (စာလုံးပေါင်း မှန်/မမှန် ပြန်စစ်ဆေးပေးပြီး ထပ်ရှာကြည့်ပါ။)
      </p>
      <Image
        src="/no-data-found.svg" // Path starting from public/
        alt="No products found"
        width={160} // Required for local/remote images (unless using 'fill')
        height={160}
        priority // Loads the image immediately (good for above-the-fold content)
        className="w-auto h-auto"
      />
    </div>
  );
};

export default NoDataFound;
