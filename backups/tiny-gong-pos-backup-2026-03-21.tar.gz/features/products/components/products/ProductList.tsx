"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useDebounceValue } from "usehooks-ts";
import { Loader2, SearchIcon } from "lucide-react";
import DualText from "@/components/DualText";
import NoDataFound from "../empty/NoDataFound";
import { useGetAllProducts } from "@/features/products/hooks";
import { CategoryGroup, SearchByValue } from "@/features/products/types";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@/components/ui/input-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type ProductSummary = CategoryGroup["products"][number];

const CATEGORY_MAP: Record<string, string> = {
  SST: "လက်တိုအင်္ကျီများ",
  LST: "လက်ရှည်အင်္ကျီများ",
  BDY: "ဘော်ဒီဝတ်စုံနှင့် ဝမ်းဆက်များ",
  PNT: "ဘောင်းဘီရှည်များ",
  JNS: "ဂျင်းဘောင်းဘီများ",
  SRT: "ဘောင်းဘီတိုများ",
  LEG: "လဂ္ဂင်းနှင့် ဂျော့ဂါဘောင်းဘီများ",
  SKT: "စကတ်နှင့် စကတ်ဘောင်းဘီများ",
  RMP: "ရော်မ်ပါနှင့် ဘောင်းဘီပုဆိုးများ",
  OUT: "အပေါ်ထပ်အင်္ကျီများ",
  SLP: "အိပ်စက်ရာတွင်ဝတ်သည့်အဝတ်အစားများ",
  SWM: "ရေကူးဝတ်စုံများ",
  UND: "အတွင်းခံနှင့် အခြေခံဝတ်စုံများ",
  ACC: "အသုံးအဆောင်ပစ္စည်းများ",
  FTW: "ဖိနပ်များ",
  DR: "ဂါဝန်များ",
  SET: "ဝမ်းဆက်ဝတ်စုံများ",
  SWT: "ဆွယ်တာနှင့် ဟူဒီများ",
};

const SEARCH_OPTIONS: Array<{ label: string; value: SearchByValue }> = [
  { label: "All", value: "all" },
  { label: "Series Code", value: "series_code" },
  { label: "Name", value: "product_name" },
  { label: "Gender", value: "gender" },
  { label: "Size", value: "size" },
  { label: "Color", value: "color" },
];

function mergeCategoryGroups(pages: CategoryGroup[][]): CategoryGroup[] {
  const groupedMap = new Map<string, CategoryGroup>();

  for (const page of pages) {
    for (const group of page) {
      const existingGroup = groupedMap.get(group.category.prefix);

      if (existingGroup) {
        existingGroup.products.push(...group.products);
        continue;
      }

      groupedMap.set(group.category.prefix, {
        category: group.category,
        products: [...group.products],
      });
    }
  }

  return Array.from(groupedMap.values());
}

function ProductSkeleton() {
  return (
    <div className="animate-pulse rounded-lg border bg-gray-50/50 p-4">
      <div className="m-auto h-16 w-16 rounded bg-gray-200" />
      <div className="mt-6 space-y-3">
        <div className="h-4 w-3/4 rounded bg-gray-200" />
        <div className="h-3 w-1/2 rounded bg-gray-100" />
        <div className="flex gap-2 pt-2">
          {[1, 2, 3].map((item) => (
            <div key={item} className="h-7 w-7 rounded-full bg-gray-100" />
          ))}
        </div>
        <div className="mt-2 h-9 w-full rounded bg-gray-200" />
      </div>
    </div>
  );
}

function ProductCard({ product }: { product: ProductSummary }) {
  return (
    <Link href={`/inventory/products/${product.id}`} className="group">
      <article className="flex flex-col gap-6 rounded-lg border bg-white p-4 shadow-sm transition-all hover:border-black hover:shadow-md">
        <figure className="flex h-16 w-16 items-center justify-center overflow-hidden rounded bg-slate-50 m-auto">
          <img
            src="/placeholder.jpg"
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
        </figure>

        <div className="flex flex-col gap-3">
          <div>
            <h3 className="truncate font-bold capitalize text-slate-900">
              {product.name}
            </h3>
            <p className="font-mono text-xs tracking-tighter text-slate-500">
              {product.series_code}
            </p>
          </div>

          <ul className="flex items-center gap-1.5">
            {product.sizes.slice(0, 3).map((size) => (
              <li
                key={size}
                className="flex h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-[10px] font-bold text-slate-600"
              >
                {size}
              </li>
            ))}
            {product.sizes.length > 3 ? (
              <li className="ml-1 text-[9px] font-bold text-slate-400">
                +{product.sizes.length - 3}
              </li>
            ) : null}
          </ul>

          <span className="w-full rounded-md bg-slate-900 py-2 text-center text-sm font-semibold text-white transition-colors group-hover:bg-black">
            View Details
          </span>
        </div>
      </article>
    </Link>
  );
}

export default function ProductList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchBy, setSearchBy] = useState<SearchByValue>("all");
  const [debouncedSearchQuery] = useDebounceValue(searchQuery, 300);

  const {
    data,
    isFetching,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isError,
    refetch,
  } = useGetAllProducts(debouncedSearchQuery.trim(), searchBy);

  const allGroups = useMemo(() => {
    if (!data?.pages) {
      return [];
    }
    return mergeCategoryGroups(data.pages);
  }, [data]);

  const isInitialLoading =
    isFetching && !isFetchingNextPage && allGroups.length === 0;

  return (
    <section className="mx-auto flex min-h-screen max-w-6xl flex-col gap-8 p-6">
      <header className="flex items-end justify-between">
        <DualText primary="Inventory" secondary="ကုန်ပစ္စည်းစာရင်း" size="md" />
        {isFetching && !isFetchingNextPage ? (
          <Loader2 className="h-5 w-5 animate-spin text-slate-400" />
        ) : null}
      </header>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Select
          value={searchBy}
          onValueChange={(value) => setSearchBy(value as SearchByValue)}
        >
          <SelectTrigger className="w-full border-slate-200 bg-white sm:w-44">
            <SelectValue placeholder="Filter By" />
          </SelectTrigger>
          <SelectContent>
            {SEARCH_OPTIONS.map((option) => (
              <SelectItem
                key={option.value}
                value={option.value}
                className="capitalize"
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <InputGroup className="flex-1 bg-white">
          <InputGroupInput
            placeholder="Search inventory..."
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            className="border-slate-200 focus:ring-1 focus:ring-black"
          />
          <InputGroupAddon>
            <SearchIcon className="h-4 w-4 text-slate-400" />
          </InputGroupAddon>
        </InputGroup>
      </div>

      <div className="space-y-12">
        {isInitialLoading ? (
          <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
            {[...Array(8)].map((_, index) => (
              <ProductSkeleton key={index} />
            ))}
          </div>
        ) : (
          <>
            {allGroups.length === 0 && !isFetching ? <NoDataFound /> : null}

            {allGroups.map((group) => (
              <section
                key={group.category.prefix}
                className="animate-in fade-in duration-500"
              >
                <header className="mb-6 flex items-center gap-4 border-b border-slate-100 pb-2">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold uppercase tracking-tighter text-indigo-600">
                      {group.category.prefix}
                    </span>
                    <DualText
                      primary={group.category.name}
                      secondary={CATEGORY_MAP[group.category.prefix] || ""}
                      size="sm"
                    />
                  </div>
                  <span className="ml-auto rounded bg-slate-50 px-2 py-1 text-xs font-medium text-slate-400">
                    {group.products.length} Items
                  </span>
                </header>

                <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
                  {group.products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </section>
            ))}

            <footer className="flex flex-col items-center gap-6 pt-10">
              {isFetchingNextPage ? (
                <div className="grid w-full grid-cols-2 gap-6 md:grid-cols-4">
                  <ProductSkeleton />
                  <ProductSkeleton />
                </div>
              ) : null}

              {hasNextPage && !isFetchingNextPage && !isError ? (
                <button
                  onClick={() => fetchNextPage()}
                  className="rounded-full border-2 border-black bg-white px-12 py-3 font-bold text-black transition-all active:scale-95 hover:bg-black hover:text-white"
                >
                  Load More
                </button>
              ) : null}

              {isError ? (
                <div className="flex w-full max-w-md flex-col items-center gap-3 rounded-2xl border border-red-100 bg-red-50 p-6">
                  <p className="text-sm font-medium text-red-600">
                    Unable to load more items.
                  </p>
                  <button
                    onClick={() => refetch()}
                    className="rounded-lg bg-red-600 px-4 py-2 text-xs font-bold uppercase tracking-widest text-white"
                  >
                    Retry Connection
                  </button>
                </div>
              ) : null}
            </footer>
          </>
        )}
      </div>
    </section>
  );
}
