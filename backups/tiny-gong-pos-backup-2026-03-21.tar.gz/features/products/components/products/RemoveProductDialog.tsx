import React from "react";
import { Trash2 } from "lucide-react";
import { Product, Variant } from "@/features/products/schema/product.schema";

interface RemoveProductDialogProps {
  valueToBeDeleted: Product | Variant;
  onRemove: (id: string) => void;
  isRemoving: boolean;
  onClose: () => void;
}
const RemoveProductDialog = ({
  valueToBeDeleted,
  onRemove,
  isRemoving,
  onClose,
}: RemoveProductDialogProps) => {
  return (
    <div className="relative w-full max-w-xl flex flex-col gap-10 px-4 py-8 bg-white rounded-t-[2.5rem] shadow-2xl animate-in slide-in-from-bottom duration-300">
      <div className="">
        <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center mb-2">
          <Trash2 size={22} className="text-red-500" />
        </div>
        <h2 className="text-2xl font-black ">Are you sure?</h2>
        <p className="text-gray-500">You are deleting This cannot be undone.</p>
      </div>

      <div className="flex gap-4 justify-center"></div>

      <div className="w-full flex gap-4">
        <button
          onClick={onClose}
          className="w-full h-16 bg-gray-50 text-gray-500 font-bold rounded-2xl hover:bg-gray-100 transition-all"
        >
          No, Go Back
        </button>
        <button
          onClick={() => onRemove(valueToBeDeleted.id)}
          disabled={isRemoving}
          className="w-full h-16 bg-red-500 text-white font-bold rounded-2xl active:scale-95 transition-all shadow-lg shadow-red-100"
        >
          {isRemoving ? "Removing now.." : "Yes, Delete It Now"}
        </button>
      </div>
    </div>
  );
};

export default RemoveProductDialogProps;
