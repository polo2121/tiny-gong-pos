"use client";

import React from "react";
import ProductInfoField from "./ProductInfoField";
import AddNewProduct from "./AddNewProduct";
import AddNewVariant from "./AddNewVariant";
import { Button } from "@base-ui/react";
import { ProductDetails, Variant } from "../../schema/product.schema";

type ProductDetailProp = {
  product: ProductDetails;
};

const ProductVariants = ({ product }: ProductDetailProp) => {
  return (
    <section className="w-full flex flex-col gap-8 p-4">
      <div className="relative flex flex-col gap-6">
        {/* image */}
        {product.variants.map((variant) => (
          <Button
            key={variant.id}
            className="relative grid grid-cols-[1fr_2fr_1fr_1fr] gap-4 py-4 px-2 rounded-2xl"
          >
            <div className="absolute top-0 w-4 h-4 rounded-full bg-blue-500 bottom-2"></div>
            <ProductInfoField label="gender" value={variant.gender} />
            <ProductInfoField label="color" value={variant.color} />
            <ProductInfoField label="size" value={variant.size} />
            <ProductInfoField label="stock" value={variant.stockQty} />
          </Button>
        ))}
      </div>

      <AddNewProduct />
      <AddNewVariant />
    </section>
  );
};

export default ProductVariants;
