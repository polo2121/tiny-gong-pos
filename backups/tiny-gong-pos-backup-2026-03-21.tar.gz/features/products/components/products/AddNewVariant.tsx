import React from "react";
import Link from "next/link";
import DualText from "@/components/DualText";
import { Button } from "@base-ui/react";

const AddNewVariant = () => {
  return (
    <Link href="" className="flex justify-between">
      <DualText
        primary="Add New Variant"
        secondary="ဒီနေ့ product အရရောင်းရဆုံးစာရင်း"
        size="md"
      />
      <Button>Go</Button>
    </Link>
  );
};

export default AddNewVariant;
