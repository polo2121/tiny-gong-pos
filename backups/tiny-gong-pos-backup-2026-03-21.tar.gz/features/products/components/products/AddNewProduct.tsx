import React from "react";
import Link from "next/link";
import DualText from "@/components/DualText";
import { Button } from "@base-ui/react";

const AddNewProduct = () => {
  return (
    <Link href="" className="flex justify-between">
      <DualText
        primary="Add New Product"
        secondary="ဒီနေ့ product အရရောင်းရဆုံးစာရင်း"
        size="md"
      />
      <Button>Go</Button>
    </Link>
  );
};

export default AddNewProduct;
