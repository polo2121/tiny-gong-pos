"use client";

import React from "react";
import {
  Product,
  CategoryList,
} from "@/features/products/schema/product.schema";
import { Button } from "@base-ui/react";

type ProductBaseProps = {
  product: Product;
  categoryList: CategoryList;
};
const ProductBase = ({ product }: ProductBaseProps) => {
  return (
    <div className="flex justify-between p-6 text-lg">
      <Button className="w-[50%] flex flex-col gap-2 text-left">
        <h4>{product.seriesCode}</h4>
        <span>{product.productName}</span>
      </Button>

      <Button className="w-[50%] flex justify-between">
        {/* Price */}
        <div className="flex flex-col gap-2">
          <h4>Price</h4>
          <span>{product.price}</span>
        </div>

        {/* Cost */}
        <div className="flex flex-col gap-2">
          <h4>Cost</h4>
          <span>{product.cost}</span>
        </div>
      </Button>
    </div>
  );
};

export default ProductBase;
