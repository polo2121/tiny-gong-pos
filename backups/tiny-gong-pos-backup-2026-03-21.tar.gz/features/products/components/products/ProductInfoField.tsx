import React from "react";

const ProductInfoField = ({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) => {
  return (
    <div className="flex flex-col gap-2 text-left capitalize">
      <dt className="text-xs text-gray-500">{label}</dt>
      <dd className="font-semibold">{value}</dd>
    </div>
  );
};

export default ProductInfoField;
