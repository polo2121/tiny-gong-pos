import React from "react";
import Image from "next/image";

const CategoryTag = ({ name }: { name: string }) => {
  return (
    <div className="category-tag bg-gray-200 h-26">
      <h4 className="w-full text-xs font-bold">{name}</h4>
    </div>
  );
};

export default CategoryTag;
