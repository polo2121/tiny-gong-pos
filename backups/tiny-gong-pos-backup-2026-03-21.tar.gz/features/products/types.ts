// Category 
export interface Categories {
  id: string;
  name: string;
  prefix: string
}
// 1. Define exact types for the Grouped Response
export interface CategoryGroup {
  category: {
    name: string;
    prefix: string;
  };
  products: {
    id: string;
    name: string;
    price: number;
    cost: number;
    series_code: string;
    sizes: string[];
    colors: string[];
    gender: string[];
  }[];
}
// 2. Use an Interface for parameters
export type SearchByValue =
  | "all"
  | "series_code"
  | "product_name"
  | "gender"
  | "size"
  | "color";

export interface GetAllProductsPayload {
  searchText?: string | null;
  searchBy?: SearchByValue;
  pageNumber?: number;
  pageSize?: number;
}


// Formatted Structure for UI
export interface ProductDetails {
  id: string;
  productName: string;
  seriesCode: string;
  price: number;
  cost: number;
  categoryId: string;
  variants: {
    id: string,
    gender: string,
    color: string,
    size : string,
    stockQty: number
  }[]
}
