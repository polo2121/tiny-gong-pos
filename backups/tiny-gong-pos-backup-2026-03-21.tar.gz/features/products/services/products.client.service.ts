import {
  ActionResult,
  RemoveVariantId,
  RemoveVariantPayload,
} from "@/features/products/schema/product.schema";
import {
  getAllProductsAction,
  removeVariantByIdAction,
} from "@/features/products/server/actions/products.server.action";
import { CategoryGroup, GetAllProductsPayload } from "@/features/products/types";


/**
 * Fetches the product catalog grouped by category.
 * Professional implementation with strict typing and defaults.
 */
export async function getAllProducts(payload: GetAllProductsPayload = {}) {
  const result = await getAllProductsAction(payload);

  if (!result.success) {
    throw new Error(result.error);
  }

  return result.data;
}

export async function removeVariantById(
  payload: RemoveVariantPayload,
): Promise<ActionResult<RemoveVariantId>> {
  return await removeVariantByIdAction(payload);
}

export const productsApiService = {
  getAllProducts,
  removeVariantById,
};
