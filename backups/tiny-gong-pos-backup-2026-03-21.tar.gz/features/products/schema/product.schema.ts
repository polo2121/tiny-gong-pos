import { z } from "zod";

/**
 * REUSABLE PRIMITIVES
 */
const requiredText = (fieldName: string) =>
  z.string().trim().min(1, `${fieldName} is required`);

const nonNegativeNumberSchema = z.number().min(0, "Amount cannot be negative");
const nonNegativeIntegerSchema = z.number().int().min(0);
const idSchema = z.uuid("Invalid ID format");

/**
 * CATEGORY SCHEMA
 */
export const categorySchema = z.object({
  id: idSchema,
  name: z.string(),
  prefix: z.string(),
});

export const categoryListSchema = z.array(categorySchema);

/**
 * PRODUCT SCHEMAS
 */
const productFieldsSchema = z.object({
  id: idSchema,
  productName: requiredText("Product name"),
  categoryId: idSchema,
  seriesCode: z.string(),
  price: nonNegativeNumberSchema.min(0, "Price must be at least 0"),
  cost: nonNegativeNumberSchema.min(0, "Cost must be at least 0"),
});

export const productSchema = z.object({
  ...productFieldsSchema.shape,
});

/**
 * VARIANT SCHEMAS
 */
const variantFieldsSchema = z.object({
  id: idSchema,
  gender: requiredText("Gender"),
  color: requiredText("Color"),
  size: requiredText("Size"),
  stockQty: nonNegativeIntegerSchema,
});

export const variantSchema = z.object({
  ...variantFieldsSchema.shape,
});

/**
 * PRODUCT DETAILS SCHEMA
 */
export const productDetailsSchema = z.object({
  ...productFieldsSchema.omit({ categoryId: true }).shape,
  categoryId: z.string(),
  variants: z.array(variantSchema).default([]),
});

export const removeVariantSchema = z.object({
  id: idSchema,
});

/**
 * TYPES
 */
export type Category = z.infer<typeof categorySchema>;
export type CategoryList = z.infer<typeof categoryListSchema>;
export type Product = z.infer<typeof productSchema>;
export type Variant = z.infer<typeof variantSchema>;
export type ProductDetails = z.infer<typeof productDetailsSchema>;

export type FieldErrors = Record<string, string[] | undefined>;

export type RemoveVariantPayload = z.infer<typeof removeVariantSchema>;
export type RemoveVariantId = RemoveVariantPayload;

export type ActionSuccessResult<TData> = {
  success: true;
  data: TData;
};

export type ActionFailureResult = {
  success: false;
  error: string;
  fieldErrors?: FieldErrors;
};

export type ActionResult<TData> =
  | ActionSuccessResult<TData>
  | ActionFailureResult;
