"use client";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { productsApiService } from "@/features/products/services";
import { RemoveVariantPayload } from "@/features/products/schema/product.schema";

const useRemoveVariant = () => {
  const router = useRouter();

  return useMutation({
    mutationFn: async (payload: RemoveVariantPayload) => {
      const result = await productsApiService.removeVariantById(payload);
      if (!result.success) {
        throw new Error(result.error);
      }

      return result.data;
    },

    onSuccess: () => {
      toast.success("Variant Removed", {
        description: "Variant was removed successfully.",
      });

      router.refresh();
    },

    onError: (error) => {
      toast.error("Remove Failed", {
        description:
          error.message ||
          "An unexpected error occurred while removing the variant.",
      });
    },
  });
};

export default useRemoveVariant;
