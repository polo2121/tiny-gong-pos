import { productsApiService } from "@/features/products/services/products.client.service";
import { useInfiniteQuery, keepPreviousData } from "@tanstack/react-query";
import { SearchByValue } from "@/features/products/types";


const useGetAllProducts = (
  searchText: string = "",
  searchBy: SearchByValue = "all",
) => {
  return useInfiniteQuery({
    // 1. The Key: Includes search params so it refetches when they change
    queryKey: ["products", searchText, searchBy],

    // 2. The Fetcher: Passes the pageParam to the service
    queryFn: ({ pageParam = 0 }) =>
      productsApiService.getAllProducts({
        searchText,
        searchBy,
        pageNumber: pageParam,
        pageSize: 50,
      }),

    initialPageParam: 0,

    // 3. The "Is there more?" Logic
    getNextPageParam: (lastPage, allPages) => {
      const loadedProductCount = lastPage.reduce(
        (count, group) => count + group.products.length,
        0,
      );
      const canLoadMore = loadedProductCount === 50;
      return canLoadMore ? allPages.length : undefined;
    },

    // 4. Smooth UI: Keeps old data visible while the new search is loading
    placeholderData: keepPreviousData,
    
    // 5. Optimization: Don't refetch on window focus in a POS system
    refetchOnWindowFocus: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
};

export default useGetAllProducts;
