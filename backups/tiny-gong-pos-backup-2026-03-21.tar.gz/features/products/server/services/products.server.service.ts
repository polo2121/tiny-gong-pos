import { createClient } from "@/lib/supabase/server";
import { requireCurrentStoreMembership } from "@/lib/auth/server";
import { canEditProducts } from "@/lib/auth/permissions";
import {
  getAllProductsByCategoryQuery,
  getProductByIdQuery,
  getVariantWithProductStore,
  removeVariantByIdQuery,
} from "@/features/products/repositories/product.repository";

import { ProductDetails, Categories } from "@/features/products";
import { RemoveVariantPayload } from "@/features/products/schema/product.schema";


import { z } from "zod";
import {
  CategoryGroup,
  GetAllProductsPayload,
} from "@/features/products/types";

export async function getAllCategories(): Promise<Categories[]> {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("categories")
    .select("id, name, prefix")
    .order("name", { ascending: true });

  // Handle real DB errors
  if (error) {
    console.error("❌ Supabase error:", {
      message: error.message,
      details: error.details,
      hint: error.hint,
      code: error.code,
    });

    throw new Error(`Database error: ${error.message}`);
  }

  // Normalize DB fields → App fields
  if (!data) return [];
  const categories = data.map((cat) => ({
    id: cat.id,
    name: cat.name,
    prefix: cat.prefix,
  }));

  return categories; // returns { id, name, prefix }[]
}

export async function getAllProductsByCategory(
  payload: GetAllProductsPayload,
): Promise<CategoryGroup[]> {
  await requireCurrentStoreMembership();

  return getAllProductsByCategoryQuery(payload);
}

// 2. The pure server-side function
export async function getProductById(
  productId: string,
){
  // if (!id) return null;
  // const isUuid = z.uuid().safeParse(id).success;
  // if (!isUuid) return null;

  const data = await getProductByIdQuery(productId);
  if (!data) return null;

  const categoryRelation = data.categoryId;
  const category = Array.isArray(categoryRelation)
    ? categoryRelation[0]
    : categoryRelation;

  if (!category) {
    return null;
  }

  const product = {
    id: data.id,
    productName: data.name,
    seriesCode: data.series_code,
    price: data.price,
    cost: data.cost,
    categoryId: category.id,
    variants: data.variants,
  };

  // const validated = productDetailsSchema.safeParse(product);

  // if (!validated.success) {
  //   reportError("products.getProductById.validation", validated.error, { id });
  //   return null;
  // }

  return product;
}
export async function removeVariantById(payload: RemoveVariantPayload) {
  const membership = await requireCurrentStoreMembership();

  if (!canEditProducts(membership.role)) {
    throw new Error("You do not have permission to remove variants.");
  }

  if (!payload.id) {
    throw new Error("Invalid ID");
  }

  const variantRecord = await getVariantWithProductStore(payload.id);
  const productRelation = variantRecord?.product;
  const product = Array.isArray(productRelation)
    ? productRelation[0]
    : productRelation;

  if (!variantRecord || !product) {
    throw new Error("Variant not found.");
  }

  if (product.store_id !== membership.storeId) {
    throw new Error("You do not have access to remove this variant.");
  }
  return await removeVariantByIdQuery(payload);
}
