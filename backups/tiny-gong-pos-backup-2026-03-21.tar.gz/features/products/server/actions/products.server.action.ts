"use server";
import { z } from "zod";
import {
  ActionResult,
  FieldErrors,
  removeVariantSchema,
  RemoveVariantId,
} from "@/features/products/schema/product.schema";
import {
  getAllProductsByCategory,
  removeVariantById,
} from "@/features/products/server/services/products.server.service";
import {
  CategoryGroup,
  GetAllProductsPayload,
} from "@/features/products/types";

function toFieldErrors(error: z.ZodError): FieldErrors {
  return z.flattenError(error).fieldErrors;
}

export async function getAllProductsAction(
  payload: GetAllProductsPayload = {},
): Promise<ActionResult<CategoryGroup[]>> {
  try {
    const data = await getAllProductsByCategory(payload);

    return {
      success: true,
      data,
    };
  } catch (error) {
    return {
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to load product catalog. Please try again later.",
    };
  }
}

export async function removeVariantByIdAction(
  payload: RemoveVariantId,
): Promise<ActionResult<{ id: string }>> {
  const validatedPayload = removeVariantSchema.safeParse(payload);

  if (!validatedPayload.success) {
    return {
      success: false,
      error: "Please fix the errors in the form.",
      fieldErrors: toFieldErrors(validatedPayload.error),
    };
  }

  try {
    const data = await removeVariantById(validatedPayload.data);

    return {
      success: true,
      data,
    };
  } catch (error) {
    return {
      success: false,
      error:
        error instanceof Error ? error.message : "Unable to remove variant.",
    };
  }
}
