"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AuthActionState, loginSchema } from "@/features/auth/schema/auth.schema";

const DEFAULT_AUTH_ERROR = "Unable to sign in with those credentials.";

export async function signInAction(
  _prevState: AuthActionState,
  formData: FormData,
): Promise<AuthActionState> {
  const validatedPayload = loginSchema.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });

  if (!validatedPayload.success) {
    return {
      error: validatedPayload.error.issues[0]?.message ?? DEFAULT_AUTH_ERROR,
    };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(validatedPayload.data);

  if (error) {
    return {
      error: error.message || DEFAULT_AUTH_ERROR,
    };
  }

  redirect("/inventory");
}

export async function signOutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
