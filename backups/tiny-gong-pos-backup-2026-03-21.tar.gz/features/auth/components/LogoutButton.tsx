import { signOutAction } from "@/features/auth/actions/auth.action";
import { Button } from "@/components/ui/button";

export default function LogoutButton() {
  return (
    <form action={signOutAction}>
      <Button type="submit" variant="outline" size="sm">
        Logout
      </Button>
    </form>
  );
}
