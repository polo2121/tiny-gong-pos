// app/error.tsx
"use client"; // Error components must be Client Components

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
      <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-4">
        <svg
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          className="w-8 h-8"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        </svg>
      </div>
      <h2 className="text-xl font-bold">Something went wrong!</h2>
      <p className="text-gray-500 mt-2 mb-6">
        The app encountered an unexpected error.
      </p>
      <button
        onClick={() => reset()} // Attempts to re-render the segment
        className="px-6 h-12 bg-black text-white rounded-xl font-bold"
      >
        Try Again
      </button>
    </div>
  );
}
