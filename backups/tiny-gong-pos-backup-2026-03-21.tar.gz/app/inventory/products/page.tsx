import React from "react";
import { CategoryGroupSection, HeaderSection } from "@/features/products";
import TodayDateLabel from "@/components/TodayDateLabel";
import ProductList from "@/features/products/components/products/ProductList";

const page = () => {
  const breadcrumbsPath = ["my-workspace", "products", "inventory"];

  return (
    <section className="inventory-page">
      <HeaderSection
        currentPath={breadcrumbsPath}
        title="Inventory"
        subtitle="ကုန်ပစ္စည်းများ"
        sideContent={<TodayDateLabel />}
      />
      <CategoryGroupSection />
      <ProductList />
    </section>
  );
};

export default page;
