import React from "react";
import {
  getProductById,
  getAllCategories,
} from "@/features/products/server/services/products.server.service";
import { HeaderSection } from "@/features/products";
import PageNotFound from "@/components/PageNotFound";
import ProductBase from "@/features/products/components/products/ProductBase";
import ProductVariants from "@/features/products/components/products/ProductVariants";

const page = async ({ params }: { params: { productId: string } }) => {
  const resolvedParams = await params;
  const [product, categories] = await Promise.all([
    getProductById(resolvedParams.productId),
    getAllCategories(), // You'll need to create this simple fetcher
  ]);

  if (!product) {
    return (
      <PageNotFound
        goBackUrl="/inventory/products"
        btnMessage="Go to Inventory"
      />
    );
  }

  return (
    <section className="flex flex-col">
      <HeaderSection
        currentPath={["my workspace", "inventory", "products", "variants"]}
        title="Product Details"
        subtitle="ကုန်ပစ္စည်းများ"
      />

      {/* Product (Name, Price, Cost) Section */}
      <ProductBase product={product} categoryList={categories} />

      <div className="px-6">
        <svg height="10" width="100%">
          <line
            x1="0"
            y1="5"
            x2="100%"
            y2="5"
            stroke="#D5D5D5"
            strokeWidth="1"
            strokeDasharray="10 15"
            strokeLinecap="round"
          />
        </svg>
      </div>

      <ProductVariants product={product} />
    </section>
  );
};

export default page;
