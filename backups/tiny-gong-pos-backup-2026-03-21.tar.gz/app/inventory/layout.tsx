"use client";
import React, { ReactNode } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@base-ui/react";
import LogoutButton from "@/features/auth/components/LogoutButton";

const layout = ({ children }: { children: ReactNode }) => {
  const router = useRouter();

  const handleBack = () => {
    // Check if the user has a history in this tab
    if (typeof window !== "undefined" && window.history.length > 1) {
      router.back();
    } else {
      // If no history, send them to a safe default page
      router.push("/products");
    }
  };
  return (
    <main className="pb-20 ">
      {children}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 z-40 h-16">
        {/* 1. The Container: Handles the Safe Area Background */}

        <div className="flex flex-col w-full ">
          {/* 2. The Content: Fixed height for the actual buttons */}
          <div className="h-16 flex items-center justify-around px-6">
            <Button onClick={handleBack}>
              <span className="text-[10px] font-bold uppercase">Go Back</span>
            </Button>

            <button className="flex flex-col items-center gap-1 text-gray-400">
              <span className="text-[10px] font-bold uppercase">Stock</span>
            </button>

            <button className="flex flex-col items-center gap-1 text-gray-400">
              <span className="text-[10px] font-bold uppercase">Settings</span>
            </button>

            <LogoutButton />
          </div>
        </div>
      </nav>
    </main>
  );
};

export default layout;
