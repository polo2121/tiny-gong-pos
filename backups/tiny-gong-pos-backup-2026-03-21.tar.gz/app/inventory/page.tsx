import React from "react";
import {
  HeaderSection,
  MetricSection,
  ExploreSection,
} from "@/features/products";

const page = () => {
  const breadcrumbsPath = ["my-workspace", "products"];
  return (
    <section className="product-layout">
      <HeaderSection
        title="Products"
        subtitle="(လက်ကျန်နည်းနေသော ကုန်ပစ္စည်းများ)"
        currentPath={["my worksapce", "products"]}
      />
      <MetricSection />
      <ExploreSection />
    </section>
  );
};

export default page;
