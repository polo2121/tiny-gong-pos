import { redirect } from "next/navigation";
import { LoginForm } from "@/features/auth";
import { createClient } from "@/lib/supabase/server";

export default async function LoginPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    redirect("/inventory");
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#fff9ec_0%,#f3efe4_100%)] px-6 py-10 text-slate-900">
      <div className="mx-auto flex min-h-[calc(100vh-5rem)] w-full max-w-md items-center">
        <section className="w-full rounded-[2rem] border border-white/70 bg-white/90 p-8 shadow-[0_30px_80px_rgba(15,23,42,0.10)] backdrop-blur">
          <div className="mb-8 space-y-3">
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-amber-700">
              Tiny Gong POS
            </p>
            <h1 className="text-3xl font-semibold tracking-tight text-slate-900">
              Welcome back
            </h1>
            <p className="text-sm leading-6 text-slate-600">
              Sign in to manage inventory, variants, and daily operations.
            </p>
          </div>

          <LoginForm />
        </section>
      </div>
    </main>
  );
}
