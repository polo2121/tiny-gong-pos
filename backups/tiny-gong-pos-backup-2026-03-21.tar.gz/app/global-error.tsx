"use client";

import { Geist, Geist_Mono } from "next/font/google";
import "@/styles/globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-white text-black`}
      >
        <div className="flex flex-col items-center justify-center min-h-[100dvh] p-6 text-center">
          <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mb-6 ring-8 ring-red-50/50">
            <svg
              className="w-10 h-10 text-red-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              />
            </svg>
          </div>

          <h1 className="text-2xl font-black mb-2">Critical System Error</h1>
          <p className="text-gray-500 max-w-xs mb-8">
            The application crashed at the root level. This might be due to a
            network failure or a major system bug.
          </p>

          <div className="w-full max-w-xs space-y-3">
            <button
              onClick={() => reset()}
              className="w-full h-16 bg-black text-white font-bold rounded-2xl active:scale-95 transition-all shadow-xl"
            >
              Attempt Recovery
            </button>

            <button
              onClick={() => window.location.reload()}
              className="w-full h-16 bg-gray-50 text-gray-400 font-bold rounded-2xl"
            >
              Force Reload App
            </button>
          </div>

          {process.env.NODE_ENV === "development" && (
            <div className="mt-8 p-4 bg-gray-100 rounded-lg text-left overflow-auto max-w-full">
              <p className="text-xs font-mono text-red-600">{error.message}</p>
            </div>
          )}
        </div>
      </body>
    </html>
  );
}
