import React from "react";
import DualText from "./DualText";

type MetricCardProps = {
  title: string;
  subtitle: string;
  value: string;
};

const MetricCard = ({ title, subtitle, value }: MetricCardProps) => {
  return (
    <div className=" flex flex-col gap-4 border border-gray-300 rounded-lg p-6 bg-gray-200">
      <DualText primary={title} secondary={subtitle} size="sm" />
      <span className="text-2xl text-gray-900 font-bold">{value}</span>
    </div>
  );
};

export default MetricCard;
