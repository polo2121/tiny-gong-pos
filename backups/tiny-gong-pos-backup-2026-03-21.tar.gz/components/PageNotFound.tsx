import Link from "next/link";
import { SearchX, ArrowLeft } from "lucide-react";

export default function PageNotFound({
  goBackUrl,
  btnMessage,
}: {
  goBackUrl: string;
  btnMessage: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-dvh p-6 text-center">
      {/* Visual Icon */}
      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-6">
        <SearchX className="w-10 h-10 text-gray-400" />
      </div>

      {/* Text Content */}
      <h1 className="text-2xl font-black text-black mb-2">
        Opps 404 Not Found
      </h1>
      <p className="text-gray-500 max-w-62.5 mb-8">
        We couldn't find the product or page you're looking for. It may have
        been deleted or moved.
      </p>

      {/* Action Buttons */}
      <div className="w-full max-w-xs space-y-3">
        <Link
          href={goBackUrl}
          className="flex items-center justify-center gap-2 w-full h-14 bg-black text-white font-bold rounded-2xl active:scale-95 transition-all shadow-lg"
        >
          <ArrowLeft size={18} />
          {btnMessage}
        </Link>

        <Link
          href="/"
          className="flex items-center justify-center w-full h-14 bg-gray-50 text-gray-600 font-semibold rounded-2xl hover:bg-gray-100 transition-colors"
        >
          Go to Dashboard
        </Link>
      </div>
    </div>
  );
}
