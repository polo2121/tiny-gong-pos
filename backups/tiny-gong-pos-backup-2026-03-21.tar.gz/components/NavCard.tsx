import React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowBigRightDashIcon } from "lucide-react";

export const NavCard = () => {
  return (
    <Link href="/inventory/products">
      {/*  Main Content */}
      <div className="flex flex-col text-left  bg-gray-100 text-gray-900 w-fit h-60 whitespace-normal justify-end py-8 rounded-[30px]">
        <span className="w-full">1.</span>
        <h2 className="w-full bg-amber-300">All Products</h2>
        <p className="w-fit">View and manage all your products in one place.</p>

        {/* Arrow Btn */}
        <div>
          <Button className="rounded-full w-10 h-10">
            <ArrowBigRightDashIcon className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Link>
  );
};
