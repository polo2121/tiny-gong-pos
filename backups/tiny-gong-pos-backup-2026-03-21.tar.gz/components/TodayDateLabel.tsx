import React from "react";

const TodayDateLabel = () => {
  const today = new Date();

  const formattedDate = today.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return <span className="text-sm text-gray-500">{formattedDate}</span>;
};

export default TodayDateLabel;
