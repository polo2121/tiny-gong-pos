import React from "react";
import { cn } from "@/lib/utils";

type DualTextProps = {
  primary: string;
  secondary: string;
  size: "xs" | "sm" | "md" | "lg";
  className?: string;
};
const DualText = ({ primary, secondary, size, className }: DualTextProps) => {
  const sizeClasses = {
    xs: {
      primary: "text-xs",
      secondary: "text-[10px]",
    },
    sm: {
      primary: "text-sm",
      secondary: "text-[10px]",
    },
    md: {
      primary: "text-lg",
      secondary: "text-xs",
    },
    lg: {
      primary: "text-3xl",
      secondary: "text-md",
    },
  };

  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <h1 className={cn(sizeClasses[size].primary, "font-bold")}>{primary}</h1>
      <p className={cn(sizeClasses[size].secondary, "text-gray-500")}>
        ({secondary})
      </p>
    </div>
  );
};

export default DualText;
